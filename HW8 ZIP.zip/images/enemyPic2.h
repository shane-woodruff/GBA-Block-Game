/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 enemyPic2 enemyPic2.png 
 * Time-stamp: Thursday 04/02/2020, 15:01:23
 * 
 * Image Information
 * -----------------
 * enemyPic2.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMYPIC2_H
#define ENEMYPIC2_H

extern const unsigned short enemyPic2[400];
#define ENEMYPIC2_SIZE 800
#define ENEMYPIC2_LENGTH 400
#define ENEMYPIC2_WIDTH 20
#define ENEMYPIC2_HEIGHT 20

#endif

