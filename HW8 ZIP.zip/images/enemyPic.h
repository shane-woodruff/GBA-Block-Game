/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 enemyPic enemyPic.png 
 * Time-stamp: Thursday 04/02/2020, 14:58:20
 * 
 * Image Information
 * -----------------
 * enemyPic.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMYPIC_H
#define ENEMYPIC_H

extern const unsigned short enemyPic[400];
#define ENEMYPIC_SIZE 800
#define ENEMYPIC_LENGTH 400
#define ENEMYPIC_WIDTH 20
#define ENEMYPIC_HEIGHT 20

#endif

