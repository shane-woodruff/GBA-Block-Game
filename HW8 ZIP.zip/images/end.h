/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 end end.png 
 * Time-stamp: Tuesday 03/31/2020, 14:38:00
 * 
 * Image Information
 * -----------------
 * end.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef END_H
#define END_H

extern const unsigned short end[38400];
#define END_SIZE 76800
#define END_LENGTH 38400
#define END_WIDTH 240
#define END_HEIGHT 160

#endif

