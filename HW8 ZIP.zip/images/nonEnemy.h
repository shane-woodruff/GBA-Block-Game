/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 nonEnemy nonEnemy.png 
 * Time-stamp: Thursday 04/02/2020, 15:01:55
 * 
 * Image Information
 * -----------------
 * nonEnemy.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NONENEMY_H
#define NONENEMY_H

extern const unsigned short nonEnemy[400];
#define NONENEMY_SIZE 800
#define NONENEMY_LENGTH 400
#define NONENEMY_WIDTH 20
#define NONENEMY_HEIGHT 20

#endif

