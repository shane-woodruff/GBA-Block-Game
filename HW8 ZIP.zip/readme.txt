*************************************
*************************************
DODGER
*************************************
BY: SHANE WOODRUFF

GAME: The object of the game is to cross the screen without hitting the red blocks
      moving from random areas of the screen. Alongside the red blocks are white
      blocks randomly moving but they will not hurt you, however they are distracting!!


					ENJOY!!